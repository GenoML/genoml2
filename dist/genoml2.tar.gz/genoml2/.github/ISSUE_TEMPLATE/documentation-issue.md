---
name: Documentation Issue
about: 'Use this template for documentation related issues. '
title: ''
labels: type:docs
assignees: ''

---

<em>Please make sure that this is a documentation issue.</em>


**System information**
- GenoML Version:
- Doc Link:


**Describe the documentation Issue**

**We welcome contributions by users. Will you be able to fix the Doc issue?**
